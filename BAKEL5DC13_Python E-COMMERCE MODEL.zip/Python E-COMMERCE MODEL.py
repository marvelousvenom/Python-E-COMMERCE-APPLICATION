class Product:
    def __init__(self, name, price, deal_price, ratings):
        self.name = name
        self.price = price
        self.deal_price = deal_price
        self.ratings = ratings
        self.you_saved = price - deal_price
        
    def display_product_details(self):
        print("Product: {}".format(self.name))
        print("Price: {}".format(self.price))
        print("Deal Price: {}".format(self.deal_price))
        print("Ratings: {}".format(self.ratings))
        print("yousaved: {}".format(self.you_saved))
        
    def get_deal_price(self):
        return self.deal_price

class Electronic_item(Product):
    def __init__(self, name, Price, deal_price, ratings, warrenty_in_months):
        super().__init__(name, Price, deal_price, ratings)
        self.warrenty_in_months = warrenty_in_months
    
    def display_product_details(self):
        super().display_product_details()
        print("warrenty : {} months".format(self.warrenty_in_months))
        print("\n")
class Grocery_item(Product):
    def __init__(self, name, Price, deal_price, ratings, expired_date):
        super().__init__(name, Price, deal_price, ratings)
        self.expired_date = expired_date
    
    def display_product_details(self):
        super().display_product_details()
        print("Expired Date : {}".format(self.expired_date))

class Laptop(Electronic_item):
    def __init__(self, name, Price, deal_price,ratings, warrenty_in_months, ram, storage):
        super().__init__(name, Price, deal_price, ratings, warrenty_in_months)
        self.ram = ram
        self.storage = storage
    def display_product_details(self):
        super().display_product_details()
        print("Ram : {} ". format(self.ram))
        print("storage: {}".format(self.storage))


class order:
    delivery_charges = {
        "Normal" : 0,
        "Prime Delivery" : 100
    }
    def __init__(self, Delivery_method, Delivery_address):
        self.items_in_cart = []
        self.Delivery_method = Delivery_method
        self.Delivery_address = Delivery_address
        
    def add_item(self, Product, quantity):
        item = (Product, quantity)
        self.items_in_cart.append(item)
        
        
    def display_order_details(self):
        print("Delivery method: {} ".format(self.Delivery_method))
        print("Delivery Address: {}".format(self.Delivery_address))
        print("Products")
        print("-----------------------------------------------------")
        for Product, quantity in self.items_in_cart:
            Product.display_product_details()
            print("Quantity: {} ".format(quantity))
            print("")
        total_bill = self.get_total_bill()
        print("Total bill : {}".format(total_bill))
        print("-----------------------------------------------------")
    def get_total_bill(self):
        total_bill = 0
        for Product,quantity in self.items_in_cart:
            total_bill += Product.get_deal_price() * quantity
            order_delivery_charges =  order.delivery_charges[self.Delivery_method]
            total_bill = total_bill + order_delivery_charges
        return total_bill
    
    @classmethod
    
    def update_delivery_charges(cls, Delivery_method, charges):
        cls.delivery_charges[Delivery_method] = charges
    
        
    



tv = Electronic_item("tv", 25000, 15000, 4.5, 24)
milk = Grocery_item("milk", 40, 30, 4.5, "Jan 2030")
my_order = order("Normal", "Hyd")
my_order.add_item(tv , 1)
my_order.add_item(milk , 3)
order.update_delivery_charges("Normal", 10)
my_order.display_order_details()
lenovo_laptop = Laptop("lenovo", 45000, 30000, 4.5, 24, "16 GB", "1 TB SSD" )
lenovo_laptop.display_product_details()